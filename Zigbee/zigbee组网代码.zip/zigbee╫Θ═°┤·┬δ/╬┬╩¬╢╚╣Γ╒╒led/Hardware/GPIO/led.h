#ifndef _LED_H
#define _LED_H

#include "stm32f10x.h"

#define zigbee_NET GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)

#define LED1_Output GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_4)
#define LED2_Output GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_5)
#define LED3_Output GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_6)
#define LED4_Output GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_7)



#define LED1_ON   GPIO_SetBits(GPIOA,GPIO_Pin_4)
#define LED2_ON 	GPIO_SetBits(GPIOA,GPIO_Pin_5)
#define LED3_ON 	GPIO_SetBits(GPIOA,GPIO_Pin_6)
#define LED4_ON 	GPIO_SetBits(GPIOA,GPIO_Pin_7)

#define LED1_OFF  GPIO_ResetBits(GPIOA,GPIO_Pin_4)
#define LED2_OFF 	GPIO_ResetBits(GPIOA,GPIO_Pin_5)
#define LED3_OFF 	GPIO_ResetBits(GPIOA,GPIO_Pin_6)
#define LED4_OFF 	GPIO_ResetBits(GPIOA,GPIO_Pin_7)

void led_init(void);  //��������
void beep_init(void); //��������


#endif
