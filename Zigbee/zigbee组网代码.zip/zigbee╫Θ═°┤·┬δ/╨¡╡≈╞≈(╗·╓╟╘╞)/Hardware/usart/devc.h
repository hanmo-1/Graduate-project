#ifndef _DEVC_H
#define _DEVC_H


#include "stm32f10x.h"

void io_init(void);

#endif
