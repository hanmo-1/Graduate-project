#ifndef _TIM_H
#define _TIM_H

#include "stm32f10x.h"

void tim3_init( u32 arr, u32 psc );
void TIM4_Configuration(void);
#endif


