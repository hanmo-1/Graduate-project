#ifndef   _USART2_H
#define   _USART2_H
#include "stm32f10x.h"
#include "usart.h"
#include "common.h"
#include <stdio.h>
#include <stdbool.h>

#if defined ( __CC_ARM   )
#pragma anon_unions
#endif

typedef struct {

    u8 strart[4];  // ��ͷ
    u8 devid;      // �豸ID
    u8 data[10];    // ����
    u8 len;        // ����
    u8 stop[4];    // ��β

} send_data_t;

typedef enum{
	C,
  R,
  E  
} ENUM_Net_TypeDef;


typedef enum{
	TC,
  BT,
  XY  
} ENUM_Net_ModeTypeDef;

#define RX_BUF_MAX_LEN     1024                                     //�����ջ����ֽ���

extern struct  STRUCT_USARTx_Fram                                  //��������֡�Ĵ����ṹ��
{
	char  Data_RX_BUF [ RX_BUF_MAX_LEN ];
	
  union {
    __IO u16 InfAll;
    struct {
		  __IO u16 FramLength       :15;                               // 14:0 
		  __IO u16 FramFinishFlag   :1;                                // 15 
	  } InfBit;
  }; 
	
} strCC2530_Fram_Record;


#define     macCC2530_Usart( fmt, ... )           USART_printf (USART2, fmt, ##__VA_ARGS__ ) 
#define     macPC_Usart( fmt, ... )                printf ( fmt, ##__VA_ARGS__ )

void usart2_io_init(void);
bool CC2530_DEV ( ENUM_Net_TypeDef enumMode );
bool CC2530_Mode ( ENUM_Net_ModeTypeDef Mode );
bool CC2530_GROUP ( void );
bool CC2530_CH ( void );
bool CC2530_PANID ( void );
bool CC2530_RESET ( void );
bool CC2530_IN_AT ( void );
bool CC2530_EXIT_AT ( void );

bool CC2530_Cmd ( char * cmd, char * reply1, char * reply2, u32 waittime );

void NET_Send(unsigned char *str, unsigned short len);
_Bool CC2530_SendString ( char * data, unsigned short len );
void NET_DEVICE_SendData(unsigned char *data, unsigned short len);

#endif
