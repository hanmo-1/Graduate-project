#ifndef _ADCX_H
#define _ADCX_H

#include "stm32f10x.h"

void ADC_Configuration(void);
void DMA_Configuration(void);
void adc_init(void);
void AD_Read(void);

#endif

